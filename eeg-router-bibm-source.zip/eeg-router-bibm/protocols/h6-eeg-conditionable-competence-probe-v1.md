# H6 EEG-Conditionable Competence Probe v1

## Scientific question

Does causal EEG contain patient-generalizable information about which frozen
seizure detector will be correct locally, beyond class prevalence, patient
identity, seizure/background recognition, and generic false-alarm risk?

The primary estimand is, for each frozen expert `m`:

`P(expert m is correct on the routed interval | causal EEG)`.

This is a mechanism probe and a Go/No-Go gate for expert routing. It is not a
performance claim for a complete MoE.

## Frozen inputs

- Experts: SingLEM, CBraMod, and TCN-GAT from the audited H6 TUSZ release.
- Expert weights are never updated.
- Main router input contains EEG only; no model ID, expert probability, or
  detector output is included.
- Primary causal context: the exact 10 s EEG window ending at the decision
  time, 16 channels, 128 Hz.
- TUSZ Eval is not read. Existing TUSZ Train/Dev outputs are development data.

## Two target definitions

### Primary: same-window competence

The 10 s EEG window and the expert decision refer to the same completed causal
window. On background, an expert is correct when it does not produce a false
alarm. On seizure, an expert is correct when it detects the event under the
frozen event-matching and latency rules. Multiple experts may be correct.

### Secondary: H6-v2 forecasting diagnosis

Reuse the frozen labels that map the preceding 10 s EEG to expert correctness
over the next 60 s. This secondary analysis explains the existing H6-v2 policy
head; it is not substituted for the primary same-window claim.

## Operating-point conditions

All competence labels are generated under three predeclared conditions:

1. Existing frozen deployed thresholds.
2. Matched-sensitivity thresholds, selected using training patients only and
   anchored to the frozen best-fixed expert sensitivity.
3. Matched-FA thresholds, selected using training patients only and anchored
   to the frozen best-fixed expert FA/24h.

Threshold selection never reads an outer validation/test patient's outcome.

## Patient partitions

- Development: patient-grouped 5-fold OOF analysis inside TUSZ Train.
- Locked exploratory evaluation: TUSZ Dev, once after all probe choices and
  gates are frozen.
- TUSZ Eval remains untouched because it was exposed by earlier H6 work.
- Any final confirmatory claim requires a genuinely unused external cohort.

No EEG windows, events, or recordings from one patient cross fit and test
partitions.

## Models and controls

The first stage is deliberately small and CPU-compatible:

1. Class-prior and always-best-expert baselines.
2. Patient-identity-only baseline.
3. EEG10 one-vs-all logistic competence probe.
4. Same-capacity EEG-to-seizure/background classifier.
5. Same-capacity EEG-to-all-FP suppressor.
6. Expert-output-only competence model, as a diagnostic comparator.
7. EEG plus expert-output competence model, as an information ceiling.

Only after the Go/No-Go signal gate passes may a raw-EEG CNN competence probe
be trained. The CNN uses three independent sigmoid outputs because expert
correctness is multi-label.

## Sampling and loss

- Training batches are stratified across seizure, actionable disagreement,
  all-expert failure, and clean background.
- Clean `[1,1,1]` background contributes to calibration and risk estimation
  but does not force an arbitrary expert ranking.
- Actionable intervals are `0 < number_correct < 3`.
- Model selection uses patient-grouped validation only.
- Formal metrics are always recomputed on the complete continuous cohort;
  actionable-only results are secondary diagnostics.

## Nulls and alternative explanations

1. Recording-local block/circular shift of competence labels, preserving
   patient, recording, prevalence, and temporal autocorrelation.
2. Global label permutation as a weaker sanity null.
3. Patient-identity-only prediction.
4. Direct seizure/background and all-FP suppressor controls.

These controls distinguish detector-specific competence information from
patient recognition and generic seizure/artifact recognition.

## Metrics

- Per-expert AUROC, AUPRC, Brier score, and calibration.
- Macro average across the three competence heads.
- Top-selection correctness and expert-selection distribution.
- Separate seizure, background, and actionable-disagreement analyses.
- OOF event sensitivity, FA/24h, and detection delay for the induced policy.
- Patient-level 2,000-replicate bootstrap intervals.
- Oracle headroom, predictable headroom, and realized policy gain.

## Go/No-Go gates

### Gate 1: competence signal

At least two of three expert heads must exceed the recording-local null after
multiple-comparison correction, with patient-bootstrap support. The signal
must not be explained by patient identity alone.

### Gate 2: clinically relevant coverage

Signal must be present in both seizure and background analyses, and the policy
must not collapse to one expert in more than 95% of decisions unless it
outperforms that fixed expert.

### Gate 3: value beyond suppression

On locked Dev, the routed policy must improve over `best fixed + the same
suppressor`, validation-fixed weights, output-only stacking, and the best
fixed expert while respecting a sensitivity-loss limit of 3 percentage
points.

Failure of Gate 1 or Gate 2 ends the MoE branch. Failure of Gate 3 identifies
false-alarm suppression, rather than expert selection, as the useful system
component.

## Execution order and concurrency

1. Preflight duplicate/overlap audit and frozen source hashes.
2. Current/future label inventory and operating-point audit (CPU).
3. EEG10 extraction/reuse audit and logistic/null probes (CPU).
4. Freeze Gate 1/2 decision.
5. Raw-EEG CNN probe only if Gates 1/2 pass and the GPU is idle.
6. Locked Dev event scoring and Gate 3.

CPU stages may run alongside the current joint-TTT job. GPU training must wait
until the formal joint-TTT queue has released the GPU.
