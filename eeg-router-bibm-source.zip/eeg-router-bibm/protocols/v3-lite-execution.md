# v3-lite execution addendum

This is a frozen subset of the v3 unified configuration. It does not modify the
original `v3-full` matrix or reinterpret any of its status entries.

## Frozen scope

- Models: `tcn_gat`, `cbramod`, and `singlem`.
- Patient splits: `17`, `42`, `3407`, `2026`, and `777`.
- Model seed: `17` only.
- Existing `split17/model_seed17` runs are counted as the first three of this
  15-run subset.
- The remaining queue contains the other four splits, three models per split,
  for 12 runs.
- Training, input views, optimizer, early stopping, validation-only threshold
  locking, one-time test evaluation, and artifact hashing remain those of
  `configs/experiment/v3_unified.yaml`.

## Interpretation

This subset estimates cross-patient-split behavior but does not estimate the full
three-seed variance on every split. The completed BSN pilot remains the separate
