# BSN-pilot-v1 frozen addendum

Frozen at **2026-08-03 20:24:41 PDT**, before any pilot validation or test result was produced.

This addendum defines a compute-matched preliminary subset of `B_Project_Protocol_v3`. It does not replace or rewrite the full v3 study. The convergence-matched v3 matrix, downstream atlas, and H1–H5 analyses continue after the BSN deadline.

## Diagnostic basis

The audited CHB-MIT unit chain is EDF µV → MNE V → explicit ×10^6 to µV → model-specific filtering/resampling → SingLEM ×0.01. The official SingLEM implementation performs the µV conversion and ×0.01 scaling but does not hard-clip to `[-1.5, 1.5]`. Across all 664 recordings and the final official 0.5–50 Hz pilot view, the exact fraction outside that interval was 2.8197%; 420 recordings exceeded 1%. This was distributed across all 16 channels and was not confined to a few records. For this pilot, the 1% rule is therefore an audit-and-report alarm, not a deletion or training stop. No abnormal recording is removed. The full study retains clipping versus no-clipping as a prespecified ablation.

Before any pilot validation or test result was viewed, the preliminary common-0.5–45 Hz audit hash was replaced by the final official-0.5–50 Hz pilot-view audit hash. This changed the audited out-of-range fraction from 2.8124% to 2.8197% and did not change the training budget, split, labels, evaluation, or interpretation rules.

The TCN-GAT 200-batch profile used batch 16, four-step gradient accumulation, four data workers, and the frozen split-17 training index. After ten warm-up batches, mean data loading, host-to-device transfer, forward, backward, and total batch times were 0.00057, 0.00174, 0.0510, 0.1050, and 0.1694 seconds. Mean GPU utilization was 85.6% (median 94%), with 15.96 GiB peak allocated memory. The corrected full-epoch estimate is 2.50 hours. The earlier 23-hour estimate came from single-worker overlapping-context reads, not repeated EDF filtering or per-sample graph construction.

## Frozen pilot design

All three models use the same 22-patient cohort, split 17, model seed 17, immutable window manifest, label definition, patient-balanced sampler, 31-window causal context, shared detection head, eventizer, and held-out test patients. Model-specific deterministic input adaptation follows each official route. SingLEM receives 0.5–50 Hz, 128 Hz, µV×0.01 input without hard clipping; CBraMod receives 0.3–75 Hz, 200 Hz, µV×0.01 input; TCN-GAT receives the v3 0.5–45 Hz, 256 Hz signal and three causal quality features. CHB-MIT uses a 60-Hz notch.

Each model receives exactly 5,000 optimizer updates with micro-batch 16 and four-step accumulation (effective batch 64; 320,000 sampled contexts). AdamW, learning rate 3×10⁻⁴, weight decay 10⁻⁴, cosine decay to 10⁻⁵, BF16, and gradient clipping at 1.0 are fixed. Checkpoints and complete validation curves are saved every 1,000 updates. The 5,000-update checkpoint is used for final validation threshold selection; no model-specific extension or best-looking checkpoint selection is permitted.

Thresholds from 0.01 to 0.99 are evaluated on validation patients only. The frozen eventizer applies causal EMA (α=1/3), minimum four-second duration, merge gaps up to ten seconds, and a 30-second refractory interval. The threshold prioritizes event sensitivity ≥0.80 and then minimizes FA/24h. Test patients are evaluated once after the threshold is frozen. Test results cannot change preprocessing, training, checkpoint choice, threshold, or eventization.

## Interpretation boundary

Results are reported as *preliminary*, *compute-budgeted*, and *not convergence-matched*. GPU time, optimizer updates, checkpoints, configuration hashes, raw continuous probabilities, event sensitivity, and FA/24h are retained. Absolute differences must not be described as proof that one architecture is superior. If TCN-GAT cannot complete the frozen minimum budget after one reproducible retry, the BSN output is limited to two completed foundation models plus explicitly partial TCN-GAT profiling.
