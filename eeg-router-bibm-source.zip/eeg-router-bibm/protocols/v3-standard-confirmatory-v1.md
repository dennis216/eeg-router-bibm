# v3-standard-confirmatory-v1

第一层标准确认实验冻结协议。

## 目标

将 compact 版本的两个患者划分扩展为患者级五折外层评估，同时保留已冻结的 CHB-MIT 窗口清单、标签、因果上下文、模型专用输入适配、事件化规则和 validation-only 阈值策略。

## 冻结实验矩阵

- 数据集：CHB-MIT，22 名规范化患者；
- 外层：5 个患者级 test fold，容量为 5/5/4/4/4；
- 每个外层 test fold 只评估一次，不参与调参；
- 其余开发患者再按患者级约 80/20 划分 train/validation；
- 模型：SingLEM、CBraMod、TCN-GAT；
- 模型随机种子：17、42、3407；
- 每个运行固定 5,000 optimizer updates，标记为 compute-matched preliminary confirmation；
- 总矩阵：5 folds × 3 models × 3 seeds = 45 runs。

## 不可变规则

1. 新 fold manifest 在读取任何新结果之前生成并锁定；
2. 同一患者的所有记录和窗口只能进入一个分区；
3. 阈值和工作点只能由 inner validation 患者选择；
4. 外层 test 在阈值冻结后只评分一次；
5. test 结果不得反过来修改 split、阈值、seed、模型或特征规则；
6. 原 `v3-compact-extension-v1` 保持不变，作为 pilot/sensitivity analysis 报告。

## 报告内容

逐患者、逐 fold 报告 event sensitivity、FA/24h、检测延迟、validation AUROC/AP 及患者级 bootstrap 置信区间；主比较使用 sensitivity–FA/24h 工作点曲线，不把不同敏感度下的单个 FA/24h 生硬地当作架构排名。

## 范围边界

本层不声称三个模型已完全收敛，不声称 H4 功能价值成立，也不替代后续的 H4-expanded、TUAR/TUEV/TUSL 外部构念验证或原始五划分 convergence-matched 研究。
