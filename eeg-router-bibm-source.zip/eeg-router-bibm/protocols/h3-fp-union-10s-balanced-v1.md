# H3 FP-union 10-second balanced multi-label classifier

This protocol is the corrected implementation for the detector-source H3
question. It is separate from the earlier midpoint-bin, softmax, duration,
and fixed-K experiments.

## Scientific question

Can pure EEG from a false-positive (FP) event predict which of the three
detectors generated an alarm, when overlapping alarms are represented by one
multi-label event and events/patients are not allowed to dominate training?

## Frozen data construction

1. Select exactly one canonical detector output per model (`fold=0`,
   `seed=17`). Other seeds are robustness analyses and are not concatenated
   into the primary dataset.
2. Keep FP intervals only.
3. Within each patient/recording, form connected components using strict
   positive-time interval overlap. A shared endpoint does not count as overlap;
   proximity merging is disabled.
4. Give each union event one target vector
   `[label_singlem, label_cbramod, label_tcn_gat]`. A window is represented
   once, even when multiple detectors contributed to the union event.
5. Starting at the union-event start, retain every complete, non-overlapping
   10-second window. Events shorter than 10 seconds are excluded and the
   incomplete tail is discarded. No arbitrary fixed number of windows is used.

## Pure EEG input

Each window is loaded from the fixed 128-Hz, 16-channel cache as a `16 x 1280`
array. The network sees only the demeaned raw EEG divided by the fixed physical
scale divisor (100). Detector probabilities, event duration, window count,
patient/recording identifiers, QC features, and HMM features are excluded from
the input.

## Patient/event balancing

All complete windows are retained. For a training window in event `e` belonging
to patient `p`, the base weight is

```
1 / (number of valid FP events for p * number of windows in e)
```

Therefore every event contributes one unit and every patient contributes one
unit before the detector-label balancing. The custom multi-label BCE gives each
detector equal loss weight and gives its positive and negative examples equal
mass. There is no oversampling, undersampling, or duplicate row for a
multi-label event.

## Model and split

The model is a pure-EEG multi-scale/dilated 1-D CNN with GroupNorm and GELU:

```
16 x 1280
  -> Conv1d(16,64,k=7,stride=2) + GroupNorm + GELU
  -> parallel Conv1d branches k=3,7,15 -> projection + residual
  -> residual dilated blocks d=1,2,4,8
  -> 128 channels -> temporal mean and standard deviation
  -> Linear(256,128) -> GELU -> Dropout -> Linear(128,3) logits
```

The three outputs are independent logits and are converted with sigmoid; this
is not a softmax single-label task. The outer split is patient-level
`GroupKFold(n_splits=5)`. Within each outer development set, validation is a
patient-level `GroupShuffleSplit`. Test is evaluated once, after the validation
checkpoint and detector-specific validation thresholds are frozen.

## Primary analysis

For each event, mean logits across its complete windows are taken before the
sigmoid. Primary performance is patient-weighted event-level macro-AUROC.
Secondary outputs are macro-AUPRC, per-detector AUROC/AUPRC, exact-match
accuracy, label accuracy, balanced accuracy, macro-F1, sensitivity, and
precision. Patient bootstrap confidence intervals use 2,000 resamples.

## Planned controls (not run by the implementation step)

The config records three preregistered controls: a prior-only comparator, a
duration-only comparator, and a patient-by-duration-stratified shuffle of the
full label vector. These controls must be run in a separate, frozen analysis
after the core model is audited; their null outputs cannot be mixed with the
primary test result.

## Files

- `configs/h3_fp_union_10s_balanced_v1.json`: frozen parameters.
- `scripts/163_build_h3_fp_union_10s_balanced_dataset.py`: data builder and
  manifest writer; refuses to overwrite an output directory.
- `scripts/164_train_h3_fp_union_10s_balanced.py`: split, model, training,
  event-level metrics, threshold locking, checkpointing, and patient bootstrap;
  refuses to overwrite an output directory.
- `scripts/165_audit_h3_fp_union_10s_balanced_dataset.py`: read-only data
  integrity audit; it checks hashes, labels, event-relative windows, and
  overlap without training.

Example commands for a later, explicitly authorized run (not executed here):

```powershell
python scripts/163_build_h3_fp_union_10s_balanced_dataset.py `
  --dataset chbmit `
  --source-event-table <canonical_fp_events.parquet> `
  --output-dir <outputs/h3-fp-union-10s-balanced-v1/chbmit> `
  --config configs/h3_fp_union_10s_balanced_v1.json

python scripts/165_audit_h3_fp_union_10s_balanced_dataset.py `
  --dataset-manifest <outputs/h3-fp-union-10s-balanced-v1/chbmit/dataset_manifest.json> `
  --output <outputs/h3-fp-union-10s-balanced-v1/chbmit/dataset_audit.json>

python scripts/164_train_h3_fp_union_10s_balanced.py `
  --dataset chbmit `
  --windows <outputs/h3-fp-union-10s-balanced-v1/chbmit/chbmit_fp_union_10s_windows.parquet> `
  --raw-cache-root <raw-cache-root> `
  --output-dir <outputs/h3-fp-union-10s-balanced-v1/chbmit/fold0_seed20260829> `
  --config configs/h3_fp_union_10s_balanced_v1.json `
  --outer-fold 0
```

The scripts are prepared only. No dataset build, training, threshold tuning, or
test evaluation was executed while implementing this protocol.
