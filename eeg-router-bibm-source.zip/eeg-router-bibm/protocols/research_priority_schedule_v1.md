# Research priority schedule v1

This schedule is tied to immutable namespaces.  It does not alter the old
compact/greedy results and does not permit test-driven tuning.

| Stage | Work | Namespace / gate | Estimated wall time |
|---|---|---|---|
| P0 | Freeze Research A release and audit 45 standard runs, H1-H5 and TUSZ | `research-a-release-v1`; complete 45/45, one test evaluation, validation-only thresholds | completed; about 1 hour |
| P1 | Four conventional baselines on standard patient GroupKFold | `v3-groupkfold-baselines-v1`; 4 models x 5 folds x 3 seeds = 60 runs; smoke before full queue | about 18-48 hours after speed calibration |
| P1 audit | Baseline aggregation, patient bootstrap, sensitivity/FA/delay tables | baseline manifest and same patient-level metric policy | about 2-6 hours |
| P2 | HMM minimal confirmatory extension | new namespace; HMM vs static null, patient bootstrap, cross-fold alignment, FDR-corrected association, frozen holdout/external check | about 24-48 hours |
| P3 | TUAR/TUEV status, transfer and label audit | separate external-data namespace; no fabricated labels; no training until cohort/hash/labels are verified | status 1-2 hours; download/transfer depends on source and bandwidth |

## Supervision policy

- Hourly heartbeat `monitor-research-priority-pipeline` checks the active stage,
  process, model/fold/seed, update count, completed-run count, GPU/CPU,
  errors, and ETA.
- A completed stage is advanced only after its manifest and hash audit passes.
- A failed or stalled stage is preserved and reported; it is not silently
  restarted or overwritten.
- P2 never selects K or tunes thresholds using outer test data.
- P3 can begin data-status and transfer checks while P2 is running, but no
  artifact-label result is reported before the label files and cohort hashes
  are verified.
