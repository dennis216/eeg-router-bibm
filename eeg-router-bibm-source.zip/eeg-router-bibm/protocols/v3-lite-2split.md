# v3-lite-2split execution addendum

Frozen at 2026-08-10 for the next compute-matched extension of
`B_Project_Protocol_v3`. This addendum is separate from both `BSN-pilot-v1` and
the full convergence-matched `v3-full` matrix. It does not overwrite or
reinterpret any existing run.

## Frozen scope

- Models: `singlem`, `cbramod`, and `tcn_gat`.
- Patient splits: `17` and `42`.
- Model seeds: `17`, `42`, and `3407`.
- Total runs: 3 models x 2 splits x 3 seeds = 18 runs.
- Output namespace: `runs/v3-lite-2split/`.
- Existing `BSN-pilot-v1` and `BSN-pilot-v1-multisplit` runs remain unchanged.
  Their artifacts may be adopted into the 18-run analysis only after an
  explicit checkpoint/probability/hash audit; they are never silently pooled.

## Training and evaluation

- 5,000 optimizer updates per run; micro-batch 16, four-step accumulation,
  effective batch size 64.
- AdamW, learning rate 3e-4, weight decay 1e-4, cosine decay to 1e-5,
  BF16, and gradient clipping at 1.0.
- Model-specific audited input views are retained; labels, 10-s windows,
  31-window causal context, patient-balanced sampling, eventizer, and
  validation-only threshold selection remain fixed.
- Checkpoints and validation curves are written every 1,000 updates.
- Each held-out test set is evaluated exactly once after the threshold lock.
- No test-set tuning, model-specific extension, or post hoc seed selection.

## Analysis gate

After all 18 runs, freeze the continuous probabilities and event tables. Run
performance summaries and H1 temporal-sharing analysis across both splits with
patient-level bootstrap and FDR correction. H2-H5 and suppressor/router work
remain deferred until this replication gate is reviewed.

## Interpretation boundary

Results are preliminary, compute-matched, and not convergence-matched. This
subset estimates cross-split robustness and does not replace the full v3 study.
