# v3 full-execution addendum

This document activates the complete `B_Project_Protocol_v3` mandatory matrix in the
separate `v3-full` namespace. It does not modify any pilot output and does not
retroactively label pilot results as preregistered full-v3 results.

## Input-unit resolution

The audited data chain is EDF physical units -> MNE volts -> explicit conversion to
microvolts. SingLEM's official route then applies `x 0.01`. The audited official
0.5-50 Hz view has 2.8197% of values outside `[-1.5, 1.5]`; these values are finite,
are distributed over recordings and channels, and are not evidence of an unresolved
unit conversion error. The official SingLEM implementation does not impose that hard
clip.

For the full v3 mandatory unified matrix, SingLEM therefore uses the deterministic
official no-hard-clip route. The existing hard-clip condition is retained as a
separate sensitivity ablation after the mandatory matrix, not silently removed. No
recording, patient, window, label, split, test set, eventizer parameter, threshold
rule, optimizer, or model seed is altered by this addendum.

## Frozen scope

- Unified matrix: 3 models x 3 model seeds x 5 patient splits = 45 runs.
- Native-configuration reasonableness check: 3 models x 3 model seeds on split 17 =
  9 runs.
- LoRA: conditional only after the protocol gate; it is not part of the startup
  queue.
- Test patients are evaluated once per completed run after checkpoint selection and
  validation-only threshold locking.

## Interpretation

All existing pilot results remain preliminary and compute-budgeted. The complete
matrix is reported separately, with its own configuration hashes, cache provenance,
checkpoint hashes, and status table. This addendum records a data-unit decision that
was already audited before pilot training; it does not claim that the full-v3 matrix
was blinded to pilot outcomes.
