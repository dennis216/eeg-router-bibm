# v3-compact-extension-v1

Frozen 2026-08-11 as a compact, preliminary extension of
`B_Project_Protocol_v3.pdf` (parent PDF SHA256:
`67cbb6e70c089b56f4de96b413ed18507b19cbb57c635b9eb218fff40ce0c1f1`).

This extension preserves the parent definitions of H1 (temporal sharing), H2
(phenotype sharing), H3 (model fingerprint), H4 (functional value), and H5
(cross-architecture transfer), while reducing the execution burden. It does
not replace, rewrite, or retroactively reinterpret the full v3 protocol.

## Frozen primary matrix

- Models: `singlem`, `cbramod`, `tcn_gat`.
- Patient splits: `split17`, `split42`.
- Model seeds: `17`, `42`, `3407`.
- Runs: 3 models × 2 splits × 3 seeds = 18.
- Training budget: exactly 5,000 optimizer updates per run.
- Micro-batch 16, four-step accumulation, effective batch 64.
- Same window manifest, patient assignment, positive/negative definition,
  causal context, eventization, threshold sweep, and one-time test evaluation.
- Test thresholds are selected from the final validation step only. No test
  tuning, post-hoc seed selection, LoRA branch, or native configuration matrix.
- Current namespace for the three newly completed runs:
  `runs/v3-lite-2split/`.

The first 15 artifacts are eligible for direct reuse only because the explicit
audit passed checkpoint SHA256, test-probability SHA256, 5,000 updates, and
single test evaluation. They are not silently pooled merely because they exist.

## Frozen data and provenance

- Dataset: CHB-MIT.
- Window manifest SHA256:
  `c46f989a660710706c81c7b9de6b6f7c7e93b869be2da847904162e229f8122f`.
- `split17.json` SHA256:
  `0af50ad0eab999fc5f6a46f2782b48aab7c8f44b4ad0a68dd7a2c0ea21c1c66e`.
- `split42.json` SHA256:
  `1f5e05159b2e8ff1169f241b1e33f608036ddc09f068b11742363038067ee6dd`.
- Pilot configuration SHA256:
  `bb8a20f2bca517c93e2ddda87179fd80f06ca08276e6593c7464ad5af6bd742e`.
- Model/input views remain model-specific and audited; the semantic cohort,
  labels, eventization, and evaluation are shared.

The 15 reused runs carry the earlier orchestration commit
`47f2029c5cc2ce6d8f2ac806e9c03d2c6b84dd9f`; the three new runs carry
`eff9b4160618a9bb3e01c034865e90d7152ad0bd`. A source audit confirmed that the
pilot runner and model implementations are unchanged between these commits;
the latter adds v3 orchestration and cache-provenance tooling. The pilot
configuration hash is identical.

## Seven-day execution sequence

### Day 1 — freeze and event library

Complete the 18-run audit, freeze continuous test probabilities and thresholds,
and build one versioned TP/FP/FN event table. The event table must record model,
split, seed, patient, recording, onset/offset, peak probability, event type,
and threshold provenance.

### Day 2 — H1 temporal sharing

- Compare cross-model FP overlap and ±30 s onset matching.
- Use 1,000 within-recording circular time shifts with minimum null shift 300 s;
  exclude blocks shorter than 720 s.
- Use 2,000 patient-level bootstrap replicates.
- Apply BH-FDR across the prespecified model pairs and report observed-versus-null
  values, confidence intervals, and effect sizes.

### Day 3 — H2 phenotype sharing and H3 model fingerprint

- Extract amplitude, spectral, spatial, raw-QC, and model-behaviour features.
- Fit scaler/PCA/clustering on train/discovery patients only; validation may
  select the frozen clustering specification; test only receives frozen labels.
- Keep both hand-crafted and hand-crafted-plus-embedding routes exploratory.
- For H3, test model enrichment while controlling patient identity and perform
  patient-centred sensitivity analysis. If identity explains the signal, report
  a patient-conditional result rather than an architecture fingerprint.

### Day 4 — H4 functional value gate

Run only one prespecified branch: phenotype-aware suppressor when phenotype
stability is supported, otherwise a router when model-specific structure is
supported. If neither gate passes, emit `negative_result` and do not search
additional branches. Required controls are threshold raising, frozen-QC rules,
same-capacity no-phenotype control, and three-model averaging. The target gate
is at least 25% FA/24 h reduction, no more than 3 percentage-point sensitivity
loss, and no more than 5 s added delay.

### Day 5 — H5 architecture-leave-one-out transfer

Run all six compact bundles (three directions × two splits):

1. SingLEM + CBraMod → TCN-GAT;
2. SingLEM + TCN-GAT → CBraMod;
3. CBraMod + TCN-GAT → SingLEM.

Report every direction and all five prespecified controls. With two splits this
is `preliminary H5 support`, not the parent protocol's 4/5-split success claim.

### Day 6 — frozen TUH external validation

- Start with a small, patient-ID-hashed smoke cohort for channel mapping and
  inference.
- Freeze CHB models, thresholds, QC rules, and phenotype prototypes before
  reading external outcomes.
- Use TUSZ for seizure detection/false alarms and TUAR/TUEV/TUSL for construct
  checks (eye, muscle, electrode, spike, and slow-wave artefacts).
- Do not retrain, rename phenotypes, or retune CHB thresholds on TUH. If full
  TUH cannot finish, report the locked patient subset as subset validation.

### Day 7 — release freeze

Produce the H1–H5 table, main figures, limitations, release manifest, and
reporting package. Every reported number must resolve to a locked CSV/Parquet
table, run manifest, and hash record.

## Interpretation boundary

Allowed wording:

> Three EEG detection routes showed preliminary, compute-matched evidence of
> temporal sharing, phenotype sharing, or model-specific structure across two
> patient splits, with frozen-model external validation planned.

Forbidden wording:

- “The full five-split v3 study is complete.”
- “All three models are fully converged.”
- Architecture superiority claims from the 5,000-update pilot alone.

Status at freeze: the 18-run primary matrix is complete and hash-audited;
H1–H5 and TUH external validation are pending analyses under this extension.
