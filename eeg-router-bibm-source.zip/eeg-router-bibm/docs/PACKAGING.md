# Packaging verification

Snapshot date: 2026-09-30.

All collected Python files passed syntax parsing. Five evaluation smoke/unit tests passed using the existing Linux oracle environment: causal EMA, event merging/refractory behavior, original maximum-overlap matching, historical matching regression, and metrics/threshold selection.

No models were retrained and no full data-dependent pipeline was rerun. A successful package check does not establish completion of the reviewer supplement.

`source_manifest.json` records the original collected source bytes. `packaged_checksums.json` records final packaged bytes, including documentation and packaging edits. The matcher was restored to the historical paper implementation; its regression test was aligned with that implementation. The later matcher is preserved in `archive/`.

The GitHub ZIP contains the full directory structure. EEG, prediction datasets, checkpoints, private correspondence and credentials are excluded. Use the local extracted folder for development; see DATA.md for external inputs.
