# A Learned Event-Level Router Increases False Alarms Across Heterogeneous EEG Seizure Detectors

Ziquan Wang*; Zixuan Luo*  
*Co-first authors  
Grandview Heights Secondary; Franklin School  
British Columbia, Canada  
ziquanwang52@gmail.com; L3407056424@gmail.com

## Abstract

Continuous EEG seizure detection must identify rare seizure events and limit false alarms over long monitoring periods. Heterogeneous detectors may provide complementary candidate events, which motivates learned event-level routing. In evaluation on held-out CHB-MIT patients, the validation-selected single-detector baseline achieved 0.578 sensitivity at 7.05 false alarms per hour (FA/h). The model-aware router achieved 0.734 sensitivity at 15.50 FA/h. The higher sensitivity was accompanied by substantially more false alarms. We examined the decisions available from the same candidate events. A full oracle reached mean sensitivity 0.922 across 15 fold–seed evaluations at 0.0029 FA/h. Forced selection preserved mean sensitivity 0.922 and increased FA/h to 26.78. Candidate choice changed the seizure match in 17 of 487 assignments. False alarms sometimes occurred at related times across detectors. Detector source was partly predictable, mainly from event duration and confidence. The oracle comparison located the largest change in false-alarm behavior at candidate-group abstention.

**Index Terms:** electroencephalography, seizure detection, model routing, ensemble learning, patient-held-out evaluation

## Introduction

Continuous EEG seizure detection must identify rare seizures and control false alarms across long recordings [1], [2]. Even a moderate hourly false-alarm rate accumulates over prolonged monitoring and increases the review burden. Event sensitivity and false alarms per unit time therefore describe complementary aspects of clinical performance [3]. Evaluation on patients excluded from model training tests whether the resulting operating points generalize across subjects.

Pretrained EEG representations now complement task-specific seizure-detection architectures. CBraMod, EpilepsyFM, and SingLEM illustrate recent approaches to transferable EEG representation learning [4], [5], [6]. Graph-based and temporal models provide another family of detector designs. Differences in learned representations, temporal processing, and decision thresholds can produce distinct candidate events on the same recording.

Routing offers a direct way to combine candidate events from heterogeneous detectors. Mixture-of-experts methods learn to allocate inputs among specialized models [7]. Recent checkpoint-expert work has also examined expert selection for wearable seizure detection [8]. An event-level router makes two practical decisions. It determines whether a candidate group produces an alarm and selects one existing detector event when an alarm is emitted.

We evaluated routing across a detector using a frozen pretrained SingLEM encoder, a CBraMod-based detector, and TCN-GAT on CHB-MIT. The learned router increased sensitivity from 0.578 to 0.734, and FA/h increased from 7.05 to 15.50. The higher sensitivity was accompanied by substantially more false alarms. Oracle analyses of the same candidate events separated candidate availability, group emission or abstention, and within-group candidate selection.

Our two primary contributions are a patient-held-out evaluation of learned event-level routing and a same-candidate oracle decomposition of its available decisions. Temporal sharing of false alarms and detector-source prediction provide supporting descriptions of the candidate events.

## Methods

### Cohort and Patient-Held-Out Evaluation

CHB-MIT contains 664 scalp EEG recordings from 22 patients and 182 annotated seizures [9]. All recordings, windows, and events from one patient remained within the same outer partition.

Five patient-level GroupKFold splits and seeds 17, 42, and 3407 gave 15 evaluations. Each outer-training partition contained an inner patient-held-out validation set. Detectors used outer-training data, operating points used validation data, and each outer-test partition was evaluated once.

The detector set comprised a detector using a frozen pretrained SingLEM encoder [6], a CBraMod-based detector, and a custom temporal-convolutional graph-attention detector (TCN-GAT). Each standard run completed 5,000 optimization updates. No detector was retrained after test results were observed.

Reported operating points are unweighted means across the 15 fold–seed evaluations. For sensitivity, each evaluation first computes its credited true positives divided by its eligible seizure instances. Summed event counts and paired patient-level differences are reported separately.

### Event Construction and Learned Routing

Window probabilities were smoothed using a causal exponential moving average with coefficient 1/3. Positive windows were converted into events using a 4-s minimum duration, a 10-s merge gap, and a 30-s refractory period. Predicted and true events were matched one-to-one when their intervals overlapped by at least 1 s. Event sensitivity was the proportion of eligible seizure events matched by a prediction. False alarms per hour (FA/h) were unmatched predicted events divided by non-seizure monitoring time.

For evaluation r, these quantities were computed as Sensitivity_r = TP_r / N_eligible,r; FA/h_r = FP_r / T_background,r (h). An event could credit at most one seizure, and a seizure could receive credit from at most one event. This preserved the clinical event unit after window smoothing, event merging, and routing.

Detector events with onsets within 30 s were assigned to the same candidate group. The learned router could select at most one existing event from a group or abstain. Each candidate member received a separate router score. The highest-scoring member was emitted when its score reached the validation-locked router threshold; otherwise, the complete group was suppressed.

Let C_g denote the retained candidates in group g, and let s_gm be the router probability for member m. The deployed action was For each group, emit the candidate with the largest router score when that score reaches the validation threshold; otherwise abstain. where τ was selected on validation patients. Peak detector probability resolved equal router scores. The chosen action returned an existing member; the router generated no new onset or detector probability.

Router inputs combined group-level detector outputs and member-level event features. Group features contained each detector's peak probability and Bernoulli uncertainty, p(1-p). Candidate identity was represented by three indicator variables in the model-aware router. Member features included event duration, peak probability, amplitude summaries, spatial dispersion, line-noise ratio, clipping and flat-signal fractions, relative power in five frequency bands, and a high-to-low-frequency ratio. The no-model-ID control set the identity indicators to zero and retained the same remaining inputs and model capacity.

Each retained member formed one training row. Members from the same group shared six group-level values: three detector peak probabilities and their three uncertainty values. Three source indicators and 15 member features completed the 24-dimensional model-aware input. Missing detector members contributed zero peak and uncertainty values. The member-specific columns preserved the duration, confidence, and EEG/QC measurements of the candidate being scored.

The router was fitted on candidate members from the outer-training patients. Median imputation and feature standardization preceded a multilayer perceptron with 64- and 32-unit hidden layers and rectified-linear activations. The binary target indicated whether each member was a true-positive or false-positive detector event, and the MLP minimized binary cross-entropy. Training used the Adam optimizer, a batch size of 64, learning rate 3×10^-4, L_2 penalty 10^-4, and at most 150 iterations without early stopping. No explicit class reweighting was applied. Each trained model produced one probability for every candidate member in the validation groups. Candidate thresholds combined 48 grid values from 0.05 to 0.99 with 20 validation-score quantiles spanning 0.50 to 0.995. The selected threshold minimized validation FA/h among settings within three percentage points of the highest validation single-detector sensitivity. Ties favored higher sensitivity and shorter delay. Outer-test patients contributed no router fitting or threshold selection.

For each fold–seed evaluation, the single-detector baseline was selected using validation data only. We first found the highest validation sensitivity among the three detectors. Detectors within three percentage points of that value were eligible, and the eligible detector with the lowest validation FA/h was selected. Ties favored higher sensitivity. Its frozen detector threshold was then used on the outer test partition.

The fusion baselines combined the three aligned window probabilities before event construction. Window rows were joined one-to-one by patient, recording, and window end time. The weighted score sequence then passed through the same event-construction procedure used for individual detectors. Equal-weight fusion assigned weight 1/3 to each detector and tested a simple static combination. Validation-fixed fusion selected nonnegative weights summing to one on a 0.25-spaced simplex grid using validation data only. It tested whether a validation-selected static mixture could combine the detector outputs without learned event-level routing. Candidate weights and the fusion threshold had to retain sensitivity within three percentage points of the highest validation single-detector sensitivity. Among eligible settings, validation FA/h was minimized, followed by higher sensitivity and shorter delay. The selected weights and threshold were frozen before test evaluation.

Candidate groups were anchored at their earliest event onset; subsequent onsets no more than 30 s after that anchor joined the group. If a detector contributed multiple events, only its highest-confidence event remained as a candidate. When the router selected a member, the scored interval began at that member's onset and ended at the latest end time among all events in the group. The unchanged scorer then applied one-to-one matching with at least 1 s of interval overlap.

**Figure.** Event-level routing and oracle evaluation. The learned router and both retrospective oracles operate on the same 30-s candidate groups and unchanged event scorer. The oracles cannot create candidate events.

### Oracle Decomposition

We separated candidate availability, group abstention, and within-group detector selection using two oracle conditions.

The full oracle received the same candidate groups and existing events as the learned router (Fig. 1). Ground truth was available for retrospective selection. Within each group, the oracle could select one existing event or abstain. The action space contained no newly created events, threshold changes, or modifications to event scoring. Seizures without a valid grouped-event action remained unmatched. The oracle first maximized the number of matched seizure instances and used overlap, delay, and peak probability to resolve assignments.

The forced-selection oracle retained the same retrospective seizure assignments. It then emitted one existing event from every remaining candidate group. This condition removed abstention and preserved the candidate events, detector thresholds, grouped intervals, and scorer. The assignment analysis counted how often the available detector choices changed whether the selected interval matched its target seizure.

Pairwise oracles repeated the full-oracle procedure after restricting each candidate group to one prespecified detector pair. They retained the grouping rule, retrospective objective, abstention action, and event scorer. Their performance quantified the seizure events available from each detector pair. All oracle conditions used frozen detector events without additional model fitting or threshold selection.

### Supporting Analyses of Candidate Events

We tested whether false-positive events occurred at related times across detectors by matching pairwise event onsets within ±30 s. Patient-level event F1 summarized the paired overlap. The null distribution used 1,000 within-recording circular shifts of the right-hand detector events. Shift offsets were at least 300 s, and recordings shorter than 720 s were excluded from the null calculation. This procedure altered event timing and preserved recording duration, event counts, and within-recording event structure. Nine detector-pair-by-seed comparisons were corrected using the Benjamini-Hochberg procedure [10].

For each patient, matches and event counts were accumulated across that patient's recordings before calculating the pairwise event F1. The primary statistic was the median of these patient-level values. An empirical one-sided probability compared the observed median with the 1,000 shifted medians, including the standard one-count correction in numerator and denominator. This design gave every patient one value in the primary statistic and retained the original event density of each recording in the null samples.

We also tested whether false-positive event features contained information about detector source. A class-balanced multinomial logistic classifier used five patient-level folds. Within each partition, the reported sensitivity analysis subtracted each patient's unlabeled feature mean. Training-set medians filled missing values, and training quantiles clipped each feature at its first and 99th percentiles. A training-fitted standard scaler was then applied before multinomial logistic regression. The classifier used C=1, balanced class weights, no dimensionality reduction, and a maximum of 500 iterations. Each outer fold fitted preprocessing and classifier parameters on its training patients before evaluating the held-out patients once. The evaluated inputs were the full feature set, duration plus peak probability, EEG/QC-only features, and a strict ten-feature EEG subset. The strict subset contained two amplitude summaries, two spatial summaries, five relative band-power values, and one high-to-low-frequency ratio. Macro-AUROC averaged one-versus-rest discrimination across the three detector labels, with 0.5 as the AUROC reference.

### Statistical Reporting

Operating points were summarized as unweighted means across the 15 fold–seed evaluations. Patient-level paired differences between the model-aware router and validation-selected single-detector baseline used 2,000 bootstrap resamples. Resampling patients retained all associated recordings and events within each draw. Confidence intervals used the 2.5th and 97.5th percentiles. The temporal-sharing analysis used empirical one-sided permutation probabilities from the 1,000 circular shifts. Its nine comparisons were adjusted together using the Benjamini–Hochberg procedure. Descriptive pooled event counts were reported separately from means across evaluations.

## Results

### Learned Routing Increased Sensitivity and False Alarms

**Table I. Patient-held-out operating points**

| Policy | Sensitivity | FA/h | |–-|–-:|–-:| | Best single | 0.578 | 7.05 | | Equal-weight average | 0.560 | 5.71 | | Validation-fixed weights | 0.588 | 3.73 | | Model-aware router | 0.734 | 15.50 | | No-model-ID router | 0.734 | 16.74 | | Forced-selection oracle | 0.922 | 26.78 | | Full oracle | 0.922 | 0.0029 |

The validation-selected single-detector baseline achieved 0.578 sensitivity at 7.05 FA/h (Table I). Equal-weight fusion achieved 0.560 sensitivity at 5.71 FA/h. Validation-fixed fusion reached 0.588 sensitivity at 3.73 FA/h.

The model-aware router increased sensitivity to 0.734 and FA/h to 15.50. Relative to the validation-selected single-detector baseline, the paired patient-level difference was +0.126 sensitivity (95% CI 0.044 to 0.207) and +8.92 FA/h (95% CI 5.42 to 12.62). The router reduced its false-alarm rate for 5 of 22 patients.

Both patient-level bootstrap intervals remained above zero. Across individual patients, the router reduced FA/h in 5 of 22 cases; the other patients had equal or higher rates.

Removing detector identity left sensitivity unchanged at 0.734 and increased FA/h to 16.74. The learned router therefore detected more seizures than the single-detector baseline, with a substantial increase in false alarms.

Among deployable policies, the model-aware router had the highest reported sensitivity. Validation-fixed fusion occupied a lower-FA operating point with a more modest sensitivity of 0.588. The no-model-ID result matched the model-aware router's sensitivity and produced 1.24 additional FA/h.

### Oracle Decomposition Separates Group Rejection from Detector Selection

Across the 15 fold–seed evaluations, 521 seizure instances were eligible for scoring. Original detector events directly overlapped 501 instances. The scored grouped interval began at the selected member's onset and ended at the latest event offset in its candidate group. This existing rule allowed one additional eligible instance to satisfy the one-second overlap criterion. A valid grouped-event action was therefore available for 502 of the 521 eligible instances.

The 501 direct overlaps comprised 201 seizure instances matched by all three detectors, 202 matched by exactly two, and 98 matched by exactly one. Among the pair-specific groups, CBraMod with TCN-GAT matched 92 instances, SingLEM with CBraMod matched 60, and SingLEM with TCN-GAT matched 50. Unique matches numbered 38 for CBraMod, 32 for TCN-GAT, and 28 for SingLEM. The remaining 20 instances had no directly overlapping detector event.

The full oracle reached 0.922 sensitivity at 0.0029 FA/h. Requiring the forced-selection oracle to emit an event from every candidate group preserved 0.922 sensitivity and increased FA/h to 26.78.

The pairwise oracles retained retrospective abstention and reached high sensitivities with few false alarms. SingLEM plus TCN-GAT reached 0.864 sensitivity at 0.0436 FA/h. CBraMod plus TCN-GAT reached 0.829 sensitivity at 0.0307 FA/h, and SingLEM plus CBraMod reached 0.815 sensitivity at 0.0697 FA/h. The three-detector oracle exceeded every pair, so each detector added seizure-associated candidates unavailable from at least one pair.

The oracle produced 487 retrospective seizure assignments. These assignments yielded 480 scorer-credited true positives across 521 eligible seizure instances. Mean sensitivity across the 15 fold–seed evaluations was 0.922, computed as the unweighted mean of each evaluation's true-positive count divided by its eligible seizure instances. The pooled count ratio was 480/521=0.9213. The 521 instances include repeated evaluation across seeds. Candidate availability and final scoring were therefore kept distinct: the former counted valid grouped actions, and the latter applied the unchanged one-to-one event matcher.

Of the 487 assignments, 195 groups contained one candidate and 292 contained multiple candidates. Every available candidate produced the same seizure-match outcome in 470 assignments. Candidate choice changed the match in the remaining 17 (Fig. 2). Removing abstention increased FA/h from 0.0029 to 26.78 with the same reported mean sensitivity. The FA/h separation arose from emitting or suppressing the remaining candidate groups.

**Figure.** Oracle decomposition. Removing abstention preserved 0.922 sensitivity and raised FA/h from 0.0029 to 26.78. Detector choice affected 17 of 487 seizure assignments.

### False Alarms Were Temporally Shared and Detector Source Was Partly Predictable

At the prespecified ±30-s onset tolerance, eight of nine detector-pair-by-seed comparisons remained significant after false-discovery-rate correction. Each comparison used 1,000 within-recording circular shifts. The shifts displaced one detector's events by at least 300 s and preserved its event count within each valid recording. The observed patient-level event F1 therefore exceeded a timing-disrupted reference in eight comparisons. Some background periods produced false alarms from multiple detectors, which constrains how often switching detector source can avoid a false event.

Detector identity was partly predictable from false-alarm features. The full feature set reached a mean macro-AUROC of 0.713, and duration plus peak probability reached 0.704. EEG/QC-only features reached 0.536; the strict ten-feature EEG set reached 0.528. Most source discrimination was therefore carried by event duration and confidence. EEG-only discrimination remained close to the 0.5 AUROC reference. The model-aware router nevertheless operated at 15.50 FA/h.

## Discussion

Across deployable policies, learned routing favored seizure recovery and static fusion favored fewer false alarms. The model-aware and no-model-ID routers reached the same sensitivity, with a small FA/h difference. Detector identity therefore contributed little to the final router operating point despite being available as an input.

A valid grouped-event action existed for 502 of 521 eligible seizure instances. Pairwise oracle sensitivities remained below the three-detector result, so the third detector expanded the available seizure-associated candidates. Removing abstention sharply changed false-alarm behavior without changing mean sensitivity. Candidate identity altered seizure matching in a small subset of assignments. The oracle conditions therefore separated the roles of candidate availability, group suppression, and within-group selection.

Temporal overlap and detector-source prediction add two views of the candidate events. Related false alarms occurred more often than expected under the circular-shift null. Duration and peak probability carried most of the detector-source information, with weaker discrimination from EEG-only features. These observations motivate reporting candidate availability, group-level alarm decisions, and within-group selection separately. Expert-selection results alone omit the alarm-control contribution of group emission.

One practical evaluation sequence follows directly from these quantities. Candidate availability records whether any grouped action can overlap each seizure. Group-level decisions count emitted events across background monitoring. Assignment analysis then measures whether candidate identity changes seizure matching. Reporting all three beside sensitivity and FA/h makes the origin of an operating point visible without combining them into a single score.

The oracle uses retrospective ground truth, and the present results concern one EEG dataset, three detector families, and one grouping and scoring protocol. Detector calibration and checkpoint selection may affect the reported operating points. The decomposition identifies the decisions that mattered in this candidate space; learning those decisions reliably remains a separate problem.

## Conclusion

Learned event-level routing recovered more seizures and also produced more false alarms than the validation-selected single detector. Oracle analysis of the same candidate events separated availability, group suppression, and within-group selection. Removing abstention sharply increased false alarms, and candidate identity changed seizure matching in relatively few assignments. Temporal-sharing and source-prediction analyses further described the candidate events. Future routed seizure systems should evaluate all three decision stages alongside event sensitivity and FA/h.

## References

[1] S. S. Farooq, A. Rehman, J. Baik, S.-J. Park, and H. Lee, “Patient-independent hybrid generative-discriminative modeling for seizure detection in long-term scalp EEG,” Scientific Reports, vol. 16, p. 27318, 2026.

[2] S. B. Wilson, M. L. Scheuer, R. G. Emerson, and A. J. Gabor, “Seizure detection: Evaluation of the reveal algorithm,” Clinical Neurophysiology, vol. 115, no. 10, pp. 2280–2291, 2004.

[3] J. Dan et al., “SzCORE: A seizure community open-source research evaluation framework for the validation of EEG-based automated seizure detection algorithms,” arXiv preprint arXiv:2402.13005, 2024.

[4] J. Wang et al., “CBraMod: A criss-cross brain foundation model for EEG decoding,” in International Conference on Learning Representations, 2025.

[5] Z. Li, N. Zhu, Y. Chen, B. Chen, Q. Dong, L. Gan, S. Zhao, Z. Yan, and T. Zhang, “EpilepsyFM: A domain-specific foundation model for epileptic representation learning using EEG signals,” Neural Networks, vol. 193, p. 108060, 2026.

[6] J. Sukhbaatar, S. Imamura, I. Inoue, S. Murakami, K. M. Hassan, S. Han, I. Chanpornpakdi, and T. Tanaka, “SingLEM: Single-channel large EEG model,” arXiv:2509.17920, 2025.

[7] R. A. Jacobs, M. I. Jordan, S. J. Nowlan, and G. E. Hinton, “Adaptive mixtures of local experts,” Neural Computation, vol. 3, no. 1, pp. 79–87, 1991.

[8] J. Germino, B. Brinkmann, N. V. Chawla, J. Cui, E. Fortune, N. Moniz, and L. Faust, “Mixture of checkpoint experts for explainable seizure detection using wearable devices,” Scientific Reports, vol. 15, p. 43976, 2025.

[9] J. Guttag, “CHB-MIT scalp EEG database,” PhysioNet, 2010.

[10] Y. Benjamini and Y. Hochberg, “Controlling the false discovery rate: A practical and powerful approach to multiple testing,” Journal of the Royal Statistical Society: Series B, vol. 57, pp. 289–300, 1995.
