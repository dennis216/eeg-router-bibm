"""Post-hoc event-selection ceiling for the frozen standard H4 outputs.

This is an audit-only analysis.  It uses event_type labels from the already
evaluated test event table to answer: if a selector knew which member of each
30-second candidate group was a TP, what event sensitivity and FA/24h could
it obtain?  It is deliberately marked non-deployable and never changes any
frozen H4 result.
"""

from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path("/root/b_false_alarm_atlas")
RUN_ID = "v3-groupkfold-confirmatory-v1"
OUT = ROOT / "outputs/reports/h4-event-oracle-ceiling-v1"
EVENT_FEATURES = ROOT / "outputs/reports" / RUN_ID / "h4_groupkfold_event_features.parquet"
BASELINE = ROOT / "outputs/reports" / RUN_ID / "h4_groupkfold_router_test.csv"
SEIZURES = ROOT / "manifests/seizures.parquet"
RECORDINGS = ROOT / "manifests/recordings.parquet"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def load_h4_helpers():
    path = ROOT / "scripts/84_run_groupkfold_h4_router.py"
    spec = importlib.util.spec_from_file_location("h4_helpers_for_oracle", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def select_perfect_member(frame: pd.DataFrame, h4) -> pd.DataFrame:
    """Select one known-TP member per 30-s candidate group, else NONE."""
    groups = h4._candidate_groups(frame)
    rows: list[dict[str, object]] = []
    if groups.empty:
        return pd.DataFrame(columns=["patient", "recording", "event_start", "event_end", "peak_probability"])
    for _, group in groups.groupby("group_id", sort=True):
        tp = group[group.event_type.astype(str) == "tp"]
        if tp.empty:
            continue
        # Any TP member yields the same truth coverage in the intended group;
        # use the highest peak as a deterministic tie-breaker.
        row = tp.sort_values(["peak_probability", "end_s"], ascending=[False, False]).iloc[0]
        rows.append(
            {
                "patient": str(row.patient),
                "recording": str(row.recording),
                "event_start": float(row.start_s),
                "event_end": float(row.group_decision_end),
                "peak_probability": float(row.peak_probability),
            }
        )
    return pd.DataFrame(rows)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    h4 = load_h4_helpers()
    events = pd.read_parquet(EVENT_FEATURES)
    baseline = pd.read_csv(BASELINE)
    seizures = pd.read_parquet(SEIZURES)
    recs = pd.read_parquet(RECORDINGS)
    durations = {str(r.recording_id): float(r.duration_s) for r in recs.itertuples(index=False)}

    rows: list[dict[str, object]] = []
    for (split, seed), frame in events[events.partition.astype(str) == "test"].groupby(["split", "seed"], sort=True):
        frame = frame.copy()
        selected = select_perfect_member(frame, h4)
        starts, patients = h4._evaluation_meta(frame)
        oracle = h4._score_events(selected, starts, patients, seizures, durations)
        b = baseline[(baseline.fold == int(split)) & (baseline.seed == int(seed)) & (baseline.method == "best_single")]
        if len(b) != 1:
            raise RuntimeError(f"missing unique best_single baseline split={split} seed={seed}")
        b = b.iloc[0]
        b_sens = float(b.sensitivity)
        b_fa = float(b.fa_per_24h)
        o_sens = float(oracle["sensitivity"])
        o_fa = float(oracle["fa_per_24h"])
        rows.append(
            {
                "split": int(split),
                "seed": int(seed),
                "baseline_method": "best_single",
                "baseline_sensitivity": b_sens,
                "baseline_fa_per_24h": b_fa,
                "oracle_sensitivity": o_sens,
                "oracle_fa_per_24h": o_fa,
                "sensitivity_gain_pp": 100.0 * (o_sens - b_sens),
                "fa_abs_change_per_24h": o_fa - b_fa,
                "fa_reduction_per_24h": b_fa - o_fa,
                "fa_relative_reduction": (b_fa - o_fa) / b_fa if b_fa > 0 else np.nan,
                "oracle_true_positive_events": int(oracle["true_positive_events"]),
                "oracle_false_alarm_events": int(oracle["false_alarm_events"]),
                "oracle_truth_events": int(oracle["truth_events"]),
                "oracle_candidate_groups_selected": int(len(selected)),
                "candidate_groups_total": int(len(h4._candidate_groups(frame).groupby("group_id"))) if not frame.empty else 0,
            }
        )

    per_run = pd.DataFrame(rows)
    per_run.to_csv(OUT / "per_run.csv", index=False)
    numeric = [
        "baseline_sensitivity",
        "oracle_sensitivity",
        "baseline_fa_per_24h",
        "oracle_fa_per_24h",
        "sensitivity_gain_pp",
        "fa_reduction_per_24h",
        "fa_relative_reduction",
    ]
    summary = {
        "status": "audit_only_non_deployable",
        "protocol_id": "h4-event-oracle-ceiling-v1",
        "source_protocol": RUN_ID,
        "oracle_definition": (
            "Within each test split/seed, group detector events using the frozen H4 +/-30 s candidate rule; "
            "select one member only when its already-known event_type is TP, otherwise select NONE. "
            "This uses test labels post hoc and is a non-deployable upper-bound analysis."
        ),
        "runs": int(len(per_run)),
        "test_labels_used_for_oracle": True,
        "model_or_threshold_selection": False,
        "source_hashes": {"event_features": sha256(EVENT_FEATURES), "baseline_test": sha256(BASELINE)},
        "means": {k: float(per_run[k].mean()) for k in numeric},
        "medians": {k: float(per_run[k].median()) for k in numeric},
        "counts": {
            "oracle_fa_lower_than_best_single": int((per_run.fa_reduction_per_24h > 0).sum()),
            "oracle_sensitivity_not_lower": int((per_run.oracle_sensitivity >= per_run.baseline_sensitivity).sum()),
            "oracle_sensitivity_strictly_higher": int((per_run.oracle_sensitivity > per_run.baseline_sensitivity).sum()),
        },
    }
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
